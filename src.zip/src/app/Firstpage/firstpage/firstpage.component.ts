import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-firstpage',
  templateUrl: './firstpage.component.html',
  styleUrls: ['./firstpage.component.scss']
})
export class FirstpageComponent implements OnInit {
  public addresses: any[] = [{
    id: 1,
    namee: '',
    age: '',
    dob: '',
    gender: ''
  }];
  ngForm: any;

  constructor() { }

  ngOnInit(): void {
  }
  addMember() {
    this.addresses.push({
      id: this.addresses.length + 1,
      namee: '',
      age: '',
      dob: '',
      gender: ''
    });
  }

  removeMember(i: number) {
    this.addresses.splice(i, 1);
  }

  logValue() {
    console.log(this.addresses);
  }
}


