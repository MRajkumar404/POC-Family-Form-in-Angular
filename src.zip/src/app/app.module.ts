import { NgModule } from '@angular/core';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { MarkAsteriskDirective } from './directives/mark-asterisk.directive';
import { FirstpageComponent } from './Firstpage/firstpage/firstpage.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MarkAsteriskDirective,
    FirstpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
