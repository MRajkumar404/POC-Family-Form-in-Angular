import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  contactForm;
 
  constructor(private formBuilder: FormBuilder) {
 
    this.contactForm = this.formBuilder.group({
      housenumber: ['', [Validators.required,]],
      ownername: ['', [Validators.required,]],
      
    });
  }

  get housenumber() {
    return this.contactForm.get('housenumber');
  }
 
  get ownername() {
    return this.contactForm.get('ownername');
  }
  onClick(){
    console.log('Form data is ', this.contactForm.value)
  }
  onReset(){
    this.contactForm.reset()
  }
onClicks(){
  
}
  ngOnInit(): void {
  }
} 
